|=======|=======|===============================|=========|=============|===============================|=======================|
|State :|	|Name :				|Version :|On Site?	|Creator			|Date of creation	|
|=======|=======|===============================|=========|=============|===============================|=======================|
	  -=A=-
Finished	acacia_door_bottom				yes	Juknum
Finished	acacia_door_bottom_hinge		    not needed	Juknum
Finished	acacia_door_top					yes	Juknum
Finished	acacia_door_top_hinge		            not needed	Juknum
Finished	acacia_trapdoor			v1.1		yes	Progical & rewrote by Juknum
Finished	activator_rail				    not needed	Progical
Finished	activator_rail_on			    not needed	Progical
Finished	activator_rail_raised			    not needed  Progical
Finished	activator_rail_on_raised		    not needed	Progical
	  -=B=-
Finished	bee_hive					yes	Juknum				23 August 2019
Finished	bee_hive_honey					yes	Juknum				23 August 2019
Finished	bee_nest					yes	Juknum				27 August 2019
Finished	bee_nest_honey					yes	Juknum				27 August 2019
Finished	birch_trapdoor			v1.1		yes	Progical & rewrote by Juknum
Finsihed	birch_door_bottom				yes	Progical
Finsnhed	birch_door_bottom_hinge			    not needed	Progical
Finished	birch_door_top					yes	Progical
Finished	birch_door_top_hinge		            not needed	Progical
Finsihed	blast_furncae					yes	Progical
Finished	brewing_stand					NO	Nekzuris (community)		25 December 2019
Finished	brown_mushroom					yes	Juknum
	  -=C=-
Finished	carved_pumpkin			v2		yes	Progical & Juknum
Finished	composter			v1.1		yes	Juknum (particle fixed)
	  -=D=-
Finished	dark_oak_trapdoor		v1.1		yes	Progical & rewrote by Juknum
Finished	dispenser			v1.1		yes	Juknum & fixed by Progical
Finished	dispenser_vertical		v1.1		yes	Juknum & fixed by Progical
Finished	detector_rail					yes	Progical
Finished	detector_rail_on			    not needed	Progical
Finished	detector_rail_raised			    not needed	Progical
Finished	detector_rail_on_raised		            not needed	Progical
Finished	dropper				v1.1		yes	Juknum & fixed by Progical
Finished	dropper_vertical		v1.1		yes	Juknum & fixed by Progical
	  -=E=-
	  -=F=-
	  -=G=-
	  -=H=-
	  -=I=-
Finished	iron_door					yes	Progical
Finished	iron_door_bottom			    not needed	Progical
Finished	iron_door_top					yes	Progical
Finished	iron_doortop_hinge			    not needed	Progical
Finished	iron_trapdoor			v1.1		yes	Progical & rewrote by Juknum
Finished	iron_bars					yes	Progical
	  -=J=-
Finished	jack_o_lantern			v2		yes	Progical & Juknum
Finished	jukebox				v2		yes	Juknum				26 August 2019
Finished	jukebox_record					yes	Howler & rewrote by Juknum	27 August 2019
Finished	jungle_trapdoor			v1.1		yes	Progical & rewrote by Juknum
	  -=K=-
	  -=L=-
Finished	ladder						yes	Juknum
Finsihed	lectern				v2		yes	Progical
May Change	loom						yes	Juknum				30 August 2019
	  -=M=-
	  -=N=-
	  -=O=-
Finished	oak_trapdoor			v1.1		yes	Progical & rewrote by Juknum
Finsihed	oak_door_bottom					yes	Progical
Finsihed	oak_door_bottom_hinge		            not needed	Progical
Finsihed	oak_door_top					yes	Progical
Finsihed	oak_door_top_hinge			    not needed	Progical
	  -=P=-
Finished	piston						yes	Juknum				26 August 2019
Finished	piston_extended				    not needed	Juknum				26 August 2019
Finished	powered_rail			v2		yes	Juknum & rewrote by Progical
Finished	powered_rail_on			v2	    not needed	Juknum & rewrote by Progical
Finished	powered_rail_raised		v2          not needed	Juknum & rewrote by Progical
Finished	powered_rail_on_raised		v2	    not needed	Juknum & rewrote by Progical
Finished	pumpkin				v1		yes	Juknum
	  -=Q=-
	  -=R=-
Finished	rail				v2		yes	Juknum & rewrote by Progical
Finished	rail_corner			v2	    not needed	Juknam & rewrote by Progical
Finished	rail_raised			v2	    not needed	Juknum & rewrote by Progical
Finished	redstone_lamp					NO	Bubminer (community)		25 December 2019
Finished	red_mushroom					yes	Juknum				20 August 2019
Finished	redstone_torch					yes	Juknum				22 August 2019
Finished	redstone_wall_torch			    not needed	Juknum				22 August 2019
	  -=S=-
Finished	smoker						NO	Juknum idea from Saarlodrie_ 	04 November 2019
Finished	smoker_on					NO	Juknum idea from Saarlodrie_ 	04 November 2019
Finished	sugar_cane					NO	Juknum				11 December 2019
Finished	sticky_piston					yes	Juknum				26 August 2019
Finished	stonecutter					yes	Juknum
	  -=T=-
Finished	template_piston_head			    not needed	Juknum				26 August 2019
	  -=U=-
	  -=V=-
	  -=W=-
	  -=X=-
	  -=Y=-
	  -=Z=-

vX.Y
 X -> significative change (appearance)
   Y -> other change
