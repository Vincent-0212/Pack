|=======|=======|===============================|=======================|===============================|=======================|
|State :|	|Name :				|Item version :		|Creator(s)			|Date of creation	|
|=======|=======|===============================|=======================|===============================|=======================|
	  -=A=-
Finished	acacia_trapdoor						Progical
Finished	acacia_boat						Juknum				28 october 2019			
	  -=B=-
Finished	birch_boat						Juknum				28 october 2019
Finished	birch_trapdoor						Progical
Finished	bow							Howler
Finished	bow_pulling_0						Howler
Finished	bow_pulling_1						Howler
Finished	bow_pulling_2						Howler
	  -=C=-
Finished	cauldron						Juknum
Finished	chest_minecart						Juknum				28 october 2019
Finished	command_block_minecart					Juknum				28 october 2019
Finished	composter						Juknum
	  -=D=-
Finished	dark_oak_trapdoor					Progical
Finished	dark_oak_boat						Juknum				28 october 2019
Finished	diamond_axe						Howler
Finished	diamond_hoe						Howler
Finished	diamond_pickaxe						Howler
Finished	diamond_shovel						Howler
Finished	diamond_sword						Howler
Finished	dragon_breath						Juknum
	  -=E=-
Finished	experience_bottle					Juknum
	  -=F=-
Finished	farmland						Juknum				30 August 2019
Finished	fishing_rod						Howler
Finished	fishing_rod_cast					Howler
Finished	flower_pot						Juknum				28 october 2019
Finished	furnace_minecart					Juknum				28 october 2019
	  -=G=-
Finished	glass_bottle						Juknum
Finished	golden_axe						Howler
Finished	golden_hoe						Howler
Finished	golden_pickaxe						Howler
Finished	golden_shovel						Howler
Finished	golden_sword						Howler
	  -=H=-
Finished	honey_bottle						Juknum
Finished	hopper							Juknum				26 August 2019
Finished	hopper_minecart						Juknum				28 october 2019
	  -=I=-
Finished	iron_axe						Howler
Finished	iron_hoe						Howler
Finished	iron_pickaxe						Howler
Finished	iron_shovel						Howler
Finished	iron_sword						Howler
Finished	iron_trapdoor						Progical
	  -=J=-
Finished	jungle_trapdoor						Progical
Finished	jungle_boat						Juknum				28 october 2019
	  -=K=-
	  -=L=-
Finished	lantern							Juknum
Finished	lingering_potion					Juknum
	  -=M=-
Finished	minecart						Juknum				28 october 2019
	  -=N=-
	  -=O=-
Finished	oak_trapdoor						Progical
Finished	oak_boat						Juknum				28 october 2019
	  -=P=-
Finished	piston							Juknum				26 August 2019
Finished	potion							Juknum
	  -=Q=-
	  -=R=-
	  -=S=-
Finished	shears							Howler
Finished	splash_potion						Howler
Finished	spruce_boat						Juknum				28 october 2019
Finished	sticky_piston						Juknum				26 August 2019
Finished	stone_axe						Howler
Finished	stone_hoe						Howler
Finished	stone_pickaxe						Howler
Finished	stone_shovel						Howler
Finished	stone_sword						Howler
Finished	stonecutter						Juknum
	  -=T=-
Finished	tnt_minecart						Juknum				28 october 2019
	  -=U=-
	  -=V=-
	  -=W=-
Finished	wooden_axe						Howler
Finished	wooden_hoe						Howler
Finished	wooden_pickaxe						Howler
Finished	wooden_shovel						Howler
Finished	wooden_sword						Howler
	  -=X=-
	  -=Y=-
	  -=Z=-

vX.Y
 X -> significative change (appearance)
   Y -> other change
